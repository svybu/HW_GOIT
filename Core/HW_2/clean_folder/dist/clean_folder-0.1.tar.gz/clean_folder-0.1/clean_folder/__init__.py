from clean_folder.clean import entry_point

__all__ = ['entry_point']